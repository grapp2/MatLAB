function [ SI ] = smallest_intensity( mat )
%SMALLEST_INTENSITY Summary of this function goes here
%   Detailed explanation goes here
SI = min(min(mat));

end

