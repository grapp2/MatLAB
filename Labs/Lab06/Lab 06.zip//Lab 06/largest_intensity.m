function [ LI ] = largest_intensity( mat )
%LARGEST_INTENSITY Summary of this function goes here
%   Detailed explanation goes here
LI = max(max(mat));

end

