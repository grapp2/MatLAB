val = input('Number ')
if val >= 10
    disp('Hello')
else
    disp('Hi')
end
