a = input('type x: ')
if a == 'x'
    disp('good job')
else
    disp('idiot')
end