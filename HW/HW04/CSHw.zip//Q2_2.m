letter = input('enter your answer: ');
switch letter
    case 'y'
        disp('OK, continuing')
    case 'n'
        disp('OK, halting')
    otherwise
        disp('error')
end
